"""
Command-line interface for Retrobranch.
"""

import argparse
import os
import re
import sys

from .engine import (
    add_pr_label,
    fetch_pr_info,
    get_maintained_branches,
    is_feature_pr,
    post_pr_comment,
    run_cmd,
    verify_issue_presence_in_branch,
)


def parse_pr_number(val: str) -> int:
    """Extracts PR number from integer, string ID, '#123', or full GitHub PR URL."""
    val_str = str(val).strip()
    match = re.search(r"/pull/(\d+)", val_str)
    if match:
        return int(match.group(1))
    if val_str.startswith("#"):
        val_str = val_str[1:]
    try:
        return int(val_str)
    except ValueError:
        raise ValueError(f"Invalid PR number or URL: '{val}'")


def main():
    parser = argparse.ArgumentParser(
        description="Retrobranch: Pre-flight decision engine for backport eligibility and triggering."
    )
    parser.add_argument(
        "pr",
        nargs="?",
        type=str,
        default=None,
        help="PR number or GitHub PR URL to evaluate (e.g. '1234' or 'https://github.com/owner/repo/pull/1234')",
    )
    parser.add_argument(
        "--pr-number",
        "--pr",
        "-p",
        type=str,
        default=None,
        help="PR number or GitHub PR URL to evaluate",
    )
    parser.add_argument("--commit", type=str, default=None, help="PR merge commit SHA (auto-detected if omitted)")
    parser.add_argument("--base-branch", type=str, default="main", help="Target base branch PR was merged into (default: main)")
    parser.add_argument("--mergify-config", type=str, default=None, help="Path to mergify.yml config (legacy option)")
    parser.add_argument(
        "--config-file",
        type=str,
        default=None,
        help="Path to branch configuration file (supports Mergify YAML, generic YAML/JSON, or text file)",
    )
    parser.add_argument(
        "--source-type",
        type=str,
        default="auto",
        choices=["auto", "mergify", "yaml", "json", "text"],
        help="Format type for branch config file (default: auto)",
    )
    parser.add_argument(
        "--target-branches",
        type=str,
        default=None,
        help="Optional comma-separated list of target branches to evaluate (e.g. 'release-2.0,release-1.0')",
    )
    parser.add_argument(
        "--filter-branches",
        type=str,
        default=None,
        help="Optional comma-separated list of branch names to filter against (e.g. 'release-2.0,release-1.0')",
    )
    parser.add_argument("--dry-run", action="store_true", help="Dry run mode without modifying labels or commenting")

    args = parser.parse_args()

    raw_pr = args.pr or args.pr_number
    if not raw_pr:
        parser.error("PR number or URL is required. Example: 'retrobranch 1234' or 'retrobranch --pr 1234'")

    try:
        pr_number = parse_pr_number(raw_pr)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    # Auto-detect config file if none specified explicitly
    config_file = args.config_file
    mergify_config = args.mergify_config
    if not config_file and not mergify_config and not args.target_branches:
        for default_path in [
            ".github/mergify.yml",
            ".github/maintained_branches.yml",
            ".github/branches.txt",
            "maintained_branches.yml",
            "branches.txt",
        ]:
            if os.path.exists(default_path):
                config_file = default_path
                break

    # 1. Fetch PR details
    pr_data = fetch_pr_info(pr_number)
    title = pr_data.get("title", "")
    labels = [l["name"] for l in pr_data.get("labels", [])]
    head_branch = pr_data.get("headRefName", "")
    base_branch = pr_data.get("baseRefName", "")
    merge_commit = args.commit or (pr_data.get("mergeCommit") or {}).get("oid")

    if not pr_data.get("mergedAt"):
        print(f"PR #{pr_number} is not merged. Skipping.")
        sys.exit(0)

    if base_branch != args.base_branch:
        print(f"PR #{pr_number} targeted '{base_branch}', not '{args.base_branch}'. Skipping backport check.")
        sys.exit(0)

    if not merge_commit:
        print(f"Error: Could not determine merge commit for PR #{pr_number}", file=sys.stderr)
        sys.exit(1)

    print(f"Evaluating PR #{pr_number}: '{title}' (Merge commit: {merge_commit[:9]})")

    # 2. Check if PR is a feature/capability
    is_feat, feat_reason = is_feature_pr(title, labels, head_branch)
    if is_feat:
        print(f"PR #{pr_number} is classified as a feature/capability: {feat_reason}. No backports added.")
        sys.exit(0)

    print(f"PR #{pr_number} is NOT a feature ({feat_reason}). Evaluating target branches...")

    # 3. Discover target maintained branches
    explicit_branches = None
    if args.target_branches:
        explicit_branches = [b.strip() for b in args.target_branches.split(",") if b.strip()]

    target_branches = get_maintained_branches(
        mergify_path=mergify_config,
        config_path=config_file,
        source_type=args.source_type,
        branch_filter=args.filter_branches,
        explicit_branches=explicit_branches,
    )
    if not target_branches:
        print("No maintained branches discovered.")
        sys.exit(0)

    print(f"Discovered target branches: {target_branches}")

    # Fetch latest branches on origin to ensure accurate git ancestry
    run_cmd(["git", "fetch", "origin", "--depth=200"] + target_branches)

    # 4. Verify presence in each target branch
    branch_results = {}
    labels_to_add = []
    skipped_branches = []

    for b in target_branches:
        label_name = f"backport-{b}"
        if label_name in labels:
            print(f"Branch '{b}' already has label '{label_name}'. Skipping check.")
            branch_results[b] = (True, "Label already present on PR", True)
            continue

        is_present, reason = verify_issue_presence_in_branch(merge_commit, b)
        branch_results[b] = (is_present, reason, False)

        if is_present:
            labels_to_add.append((b, label_name))
        else:
            skipped_branches.append((b, label_name, reason))

    # 5. Apply labels for branches where issue is present
    for b, label_name in labels_to_add:
        add_pr_label(pr_number, label_name, dry_run=args.dry_run)

    # 6. If any branch was skipped due to issue not being present, post comment report
    if skipped_branches:
        table_rows = []
        for b, (is_present, reason, already_had) in branch_results.items():
            lbl = f"`backport-{b}`"
            if already_had:
                status = "ℹ️ Already present"
                detail = "Label was already attached to the PR."
            elif is_present:
                status = "✅ Label added"
                detail = f"Verified present. Added {lbl} label."
            else:
                status = "⏭️ Skipped"
                detail = f"**Issue not present**: {reason}"
            table_rows.append(f"| `{b}` | {status} | {detail} |")

        comment_body = (
            f"### 🤖 Retrobranch Backport Verification Report\n\n"
            f"This PR was merged into `{args.base_branch}` and evaluated for backporting to maintained branches:\n\n"
            f"| Target Branch | Status | Details |\n"
            f"| :--- | :--- | :--- |\n"
            + "\n".join(table_rows)
            + "\n\n"
            f"*Note: For skipped branches, the issue or code being addressed was not present. "
            f"If this fix is still desired on a skipped branch, maintainers can apply the backport label manually.*"
        )
        post_pr_comment(pr_number, comment_body, dry_run=args.dry_run)


if __name__ == "__main__":
    main()

